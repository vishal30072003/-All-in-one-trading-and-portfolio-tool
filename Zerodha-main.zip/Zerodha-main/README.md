# Zerodha
Please try to implement the project on your own before proceeding to the lectures &amp; code.
